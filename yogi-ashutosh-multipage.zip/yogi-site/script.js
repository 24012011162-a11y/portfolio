document.addEventListener('DOMContentLoaded', function () {
  // Nav scroll
  var nav = document.querySelector('nav');
  window.addEventListener('scroll', function () {
    nav && (window.scrollY > 20 ? nav.classList.add('scrolled') : nav.classList.remove('scrolled'));
  });

  // Active nav link
  var navLinks = document.querySelectorAll('.nav-links a');
  var page = location.pathname.split('/').pop() || 'index.html';
  navLinks.forEach(function (a) {
    if (a.getAttribute('href') === page) a.classList.add('active');
  });

  // Mobile toggle
  var toggle = document.querySelector('.mobile-toggle');
  var links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      links.style.display = links.style.display === 'flex' ? 'none' : 'flex';
      links.style.flexDirection = 'column';
      links.style.position = 'absolute';
      links.style.top = '100%';
      links.style.left = '0';
      links.style.right = '0';
      links.style.background = 'var(--off)';
      links.style.padding = '1rem 2rem';
      links.style.borderBottom = '1px solid rgba(212,114,42,0.15)';
    });
  }

  // Back to top
  var btn = document.getElementById('back-to-top');
  if (btn) {
    window.addEventListener('scroll', function () {
      window.scrollY > 600 ? btn.classList.add('visible') : btn.classList.remove('visible');
    });
    btn.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
  }

  // Scroll reveal for award items
  var items = document.querySelectorAll('.award-item');
  if ('IntersectionObserver' in window && items.length) {
    var obs = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target); }
      });
    }, { threshold: 0.1 });
    items.forEach(function (i) { obs.observe(i); });
  } else {
    items.forEach(function (i) { i.classList.add('visible'); });
  }

  // Contact form
  var form = document.getElementById('contact-form');
  if (form) {
    var status = document.getElementById('form-status');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var name = document.getElementById('cf-name');
      var email = document.getElementById('cf-email');
      var msg = document.getElementById('cf-message');
      var valid = true;
      [name, email, msg].forEach(function (f) { f.classList.remove('error'); if (!f.value.trim()) { f.classList.add('error'); valid = false; } });
      if (email.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) { email.classList.add('error'); valid = false; }
      if (!valid) { status.textContent = 'Please fill all required fields.'; status.className = 'form-status error'; return; }
      var sub = form.querySelector('.form-submit');
      sub.disabled = true; sub.textContent = 'Sending...';
      setTimeout(function () {
        status.textContent = 'Thank you. Your message has been received.';
        status.className = 'form-status success';
        sub.disabled = false; sub.textContent = 'Send message';
        form.reset();
      }, 900);
    });
  }
});
